import React from "react";
import "./App.css";
import WishList from "./components/WishList";

function App() {
  return (
    <div className="App">
      <WishList />
    </div>
  );
}

export default App;
