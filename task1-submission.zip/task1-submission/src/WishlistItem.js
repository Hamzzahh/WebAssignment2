import React from 'react';
import { Card, Button, Form, Row, Col } from 'react-bootstrap';

const WishlistItem = ({ item, index, removeItem, updatePriority, moveToTop }) => {
    return (
        <Card className="mb-3">
            <Card.Body>
                <Row>
                    <Col>
                        <h5>{item.name}</h5>
                        <p>Priority: {item.priority}</p>
                    </Col>
                    <Col md="auto">
                        <Form.Control
                            as="select"
                            value={item.priority}
                            onChange={(e) => updatePriority(index, e.target.value)}
                            className="mb-2"
                        >
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                        </Form.Control>
                        <Button variant="info" onClick={() => moveToTop(index)} className="mb-2 mr-2">
                            Move to Top
                        </Button>
                        <Button variant="danger" onClick={() => removeItem(index)}>
                            Remove
                        </Button>
                    </Col>
                </Row>
            </Card.Body>
        </Card>
    );
};

export default WishlistItem
