import React from 'react';

const WishItem = ({ item, index, onRemove, onUpdatePriority, onMoveToTop }) => {
    const priorities = [
        { value: 'lowest', label: 'Lowest' },
        { value: 'low', label: 'Low' },
        { value: 'medium', label: 'Medium' },
        { value: 'high', label: 'High' },
        { value: 'highest', label: 'Highest' },
    ];

    const handlePriorityChange = (event) => {
        onUpdatePriority(index, event.target.value);
    };

    return (
        <li className="list-group-item d-flex justify-content-between align-items-center">
            <span className="flex-grow-1">{item.text}</span>
            <select
                className="form-select me-2"
                value={item.priority}
                onChange={handlePriorityChange}
            >
                {priorities.map((priority) => (
                    <option key={priority.value} value={priority.value}>
                        {priority.label}
                    </option>
                ))}
            </select>
            <button className="btn btn-danger me-2" onClick={() => onRemove(index)}>
                Remove
            </button>
            <button className="btn btn-primary" onClick={() => onMoveToTop(index)}>
                Move to Top
            </button>
        </li>
    );
};

export default WishItem;
