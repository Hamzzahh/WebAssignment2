import React, { useState } from "react";
import WishItem from "./WishItem";

const WishList = () => {
    const [items, setItems] = useState([]);
    const [inputValue, setInputValue] = useState("");
    const [inputPriority, setInputPriority] = useState("lowest");

    const priorityValues = {
        lowest: 1,
        low: 2,
        medium: 3,
        high: 4,
        highest: 5,
    };

    const addItem = () => {
        if (inputValue.trim()) {
            const newItem = { text: inputValue, priority: inputPriority };
            const updatedItems = [...items, newItem].sort(
                (a, b) => priorityValues[b.priority] - priorityValues[a.priority]
            );
            setItems(updatedItems);
            setInputValue("");
            setInputPriority("lowest"); // reset the priority input
        }
    };

    const removeItem = (index) => {
        setItems(items.filter((_, i) => i !== index));
    };

    const updatePriority = (index, priority) => {
        const updatedItems = [...items];
        updatedItems[index].priority = priority;
        setItems(
            updatedItems.sort(
                (a, b) => priorityValues[b.priority] - priorityValues[a.priority]
            )
        );
    };

    const moveToTop = (index) => {
        const itemToMove = items[index];
        itemToMove.priority = 'highest'; // Change priority to highest
        const updatedItems = items.filter((_, i) => i !== index);
        setItems([itemToMove, ...updatedItems]);
    };

    return (
        <div className="container">
            <h1 className="text-center my-4">Wish List 20L-1323</h1>
            <div className="input-group mb-3">
                <input
                    type="text"
                    className="form-control"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Add an item"
                />
                <select
                    className="form-select"
                    value={inputPriority}
                    onChange={(e) => setInputPriority(e.target.value)}
                >
                    <option value="lowest">Lowest</option>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="highest">Highest</option>
                </select>
                <button className="btn btn-primary" onClick={addItem}>
                    Add Item
                </button>
            </div>
            <ul className="list-group">
                {items.map((item, index) => (
                    <WishItem
                        key={index}
                        item={item}
                        index={index}
                        onRemove={removeItem}
                        onUpdatePriority={updatePriority}
                        onMoveToTop={moveToTop}
                    />
                ))}
            </ul>
        </div>
    );
};

export default WishList;
