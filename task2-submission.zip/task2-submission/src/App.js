import React, { useState } from 'react';
import SearchBar from './SearchBar';
import UserProfile from './UserProfile';

const App = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState([]);

  const searchUsers = async (query) => {
    setSearchQuery(query);
    if (query) {
      try {
        const response = await fetch(
          `https://api.github.com/search/users?q=${query}&per_page=10`
        );
        const data = await response.json();
        setUsers(data.items);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    } else {
      setUsers([]);
    }
  };

  return (
    <div className="container">
      <h1 className="my-4">GitHub User Search (20L-1323)</h1>
      <SearchBar onSearch={searchUsers} />
      {searchQuery && !users.length && (
        <div className="alert alert-info">No users found for "{searchQuery}"</div>
      )}
      <div className="row">
        {users.map((user) => (
          <div key={user.id} className="col-md-6">
            <UserProfile user={user} />
          </div>
        ))}
      </div>
    </div>
  );
};

export default App;
