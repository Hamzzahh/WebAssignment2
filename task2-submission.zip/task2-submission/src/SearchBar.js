import React from 'react';

const SearchBar = ({ onSearch }) => {
    const [input, setInput] = React.useState('');

    const handleSearch = (e) => {
        e.preventDefault();
        onSearch(input);
    };

    return (
        <form className="mb-3" onSubmit={handleSearch}>
            <div className="input-group">
                <input
                    type="text"
                    className="form-control"
                    placeholder="Search GitHub username"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                />
                <button className="btn btn-primary mx-3" type="submit">
                    Search
                </button>
            </div>
        </form>
    );
};

export default SearchBar;
